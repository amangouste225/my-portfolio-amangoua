<?php
defined('ABSPATH') || die('Cheatin\' uh?');

class HMWP_Controllers_Widget extends HMWP_Classes_FrontController {

    public $riskreport = array();
    public $risktasks;
    public $stats = false;

    /**
     * Called when dashboard is loaded
     * @throws Exception
     */
    public function dashboard() {
        //Get the stats
        $args = array();
        //If it's multisite
        if(is_multisite()) {
            if ( function_exists( 'get_sites' ) && class_exists( 'WP_Site_Query' ) ) {
                $sites = get_sites();
                if(!empty($sites)) {
                    foreach ($sites as $site) {
                        $urls[] = (_HMWP_CHECK_SSL_ ? 'https://' : 'http://') . rtrim($site->domain . $site->path,'/');
                    }
                }
            }
        }else{
            $urls[] = home_url();
        }
        //pack the urls
        $args['urls'] = json_encode(array_unique($urls));

        //call the stats
        $stats = HMWP_Classes_Tools::hmwp_remote_get(_HMWP_API_SITE_ . '/api/log/stats', $args );

        if ($stats = json_decode($stats, true)) {
            if(isset($stats['data'])) {
                $this->stats = $stats['data'];
            }
        }

        $this->risktasks = HMWP_Classes_ObjController::getClass('HMWP_Controllers_SecurityCheck')->getRiskTasks();
        $this->riskreport = HMWP_Classes_ObjController::getClass('HMWP_Controllers_SecurityCheck')->getRiskReport();


        echo $this->getView('Dashboard');
    }

    /**
     * Called when an action is triggered
     * @throws Exception
     */
    public function action() {
        parent::action();

        if (!HMWP_Classes_Tools::userCan('hmwp_manage_settings')) {
            return;
        }

        switch (HMWP_Classes_Tools::getValue('action')) {
            case 'hmwp_widget_securitycheck':
                HMWP_Classes_ObjController::getClass('HMWP_Controllers_SecurityCheck')->doSecurityCheck();

                //Get the stats
                $args = array();
                //If it's multisite
                if(is_multisite()) {
                    if ( function_exists( 'get_sites' ) && class_exists( 'WP_Site_Query' ) ) {
                        $sites = get_sites();
                        if(!empty($sites)) {
                            foreach ($sites as $site) {
                                $urls[] = (_HMWP_CHECK_SSL_ ? 'https://' : 'http://') . rtrim($site->domain . $site->path,'/');
                            }
                        }
                    }
                }else{
                    $urls[] = home_url();
                }
                //pack the urls
                $args['urls'] = json_encode(array_unique($urls));
                //call the stats
                $stats = HMWP_Classes_Tools::hmwp_remote_get(_HMWP_API_SITE_ . '/api/log/stats', $args );

                if ($stats = json_decode($stats, true)) {
                    if(isset($stats['data'])) {
                        $this->stats = $stats['data'];
                    }
                }

                $this->risktasks = HMWP_Classes_ObjController::getClass('HMWP_Controllers_SecurityCheck')->getRiskTasks();
                $this->riskreport = HMWP_Classes_ObjController::getClass('HMWP_Controllers_SecurityCheck')->getRiskReport();

                HMWP_Classes_Tools::setHeader('json');
                echo json_encode(array('data' => $this->getView('Dashboard')));
                exit();

        }
    }
}
