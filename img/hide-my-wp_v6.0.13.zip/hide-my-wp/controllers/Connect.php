<?php
defined( 'ABSPATH' ) || die( 'Cheatin\' uh?' );

class HMWP_Controllers_Connect extends HMWP_Classes_FrontController {

    /**
     * Called when an action is triggered
     * @throws Exception
     */
    public function action() {
        parent::action();

        if ( !HMWP_Classes_Tools::userCan( 'hmwp_manage_settings' ) ) {
            return;
        }

        switch ( HMWP_Classes_Tools::getValue( 'action' ) ) {
            case 'hmwp_connect':
                //Connect to API with the Token
                $token = HMWP_Classes_Tools::getValue( 'hmwp_token', '' );

                $redirect_to = HMWP_Classes_Tools::getSettingsUrl();
                if ( $token <> '' ) {
                    if ( preg_match( '/^[a-z0-9\-]{32}$/i', $token ) ) {
                        HMWP_Classes_Tools::checkAccountApi( $token, $redirect_to );
                    } else {
                        HMWP_Classes_Error::setError( __( 'ERROR! Please make sure you use a valid token to activate the plugin', _HMWP_PLUGIN_NAME_ ) . " <br /> " );
                    }
                } else {
                    HMWP_Classes_Error::setError( __( 'ERROR! Please make sure you use the right token to activate the plugin', _HMWP_PLUGIN_NAME_ ) . " <br /> " );
                }
                break;

        }
    }

}
