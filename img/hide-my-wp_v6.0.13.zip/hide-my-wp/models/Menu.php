<?php
defined('ABSPATH') || die('Cheatin\' uh?');

class HMWP_Models_Menu {

    /**
     * Get the admin Menu Tabs
     * @return array
     * @throws Exception
     */
    public function getMenu() {

        $menu =  array(
            'hmwp_settings' => array(
                'name' => esc_html__("Overview", _HMWP_PLUGIN_NAME_). ' ' . apply_filters('hmwp_alert_count', ''),
                'title' => esc_html__("Overview", _HMWP_PLUGIN_NAME_),
                'capability' => 'hmwp_manage_settings',
                'parent' => 'hmwp_settings',
                'function' => array(HMWP_Classes_ObjController::getClass( 'HMWP_Controllers_Overview' ), 'init'),
            ),
            'hmwp_permalinks' => array(
                'name' => esc_html__( "Change Paths", _HMWP_PLUGIN_NAME_ ),
                'title' => esc_html__( "Change Paths", _HMWP_PLUGIN_NAME_ ),
                'capability' => 'hmwp_manage_settings',
                'parent' => 'hmwp_settings',
                'function' => array(HMWP_Classes_ObjController::getClass( 'HMWP_Controllers_Settings' ), 'init'),
            ),
            'hmwp_tweaks' => array(
                'name' => esc_html__( "Tweaks", _HMWP_PLUGIN_NAME_ ),
                'title' => esc_html__( "Tweaks", _HMWP_PLUGIN_NAME_ ),
                'capability' => 'hmwp_manage_settings',
                'parent' => 'hmwp_settings',
                'function' => array(HMWP_Classes_ObjController::getClass( 'HMWP_Controllers_Settings' ), 'init'),
            ),
            'hmwp_mapping' => array(
                'name' => esc_html__( "Mapping", _HMWP_PLUGIN_NAME_ ),
                'title' => esc_html__( "Text & URL Mapping", _HMWP_PLUGIN_NAME_ ),
                'capability' => 'hmwp_manage_settings',
                'parent' => 'hmwp_settings',
                'function' => array(HMWP_Classes_ObjController::getClass( 'HMWP_Controllers_Settings' ), 'init'),
            ),
            'hmwp_brute' => array(
                'name' => esc_html__( "Brute Force", _HMWP_PLUGIN_NAME_ ),
                'title' => esc_html__("Brute Force", _HMWP_PLUGIN_NAME_),
                'capability' => 'hmwp_manage_settings',
                'parent' => 'hmwp_settings',
                'function' => array(HMWP_Classes_ObjController::getClass( 'HMWP_Controllers_Settings' ), 'init'),
            ),
            'hmwp_log' => array(
                'name' => esc_html__( "Events Log", _HMWP_PLUGIN_NAME_ ),
                'title' => esc_html__("Events Log", _HMWP_PLUGIN_NAME_),
                'capability' => 'hmwp_manage_settings',
                'parent' => 'hmwp_settings',
                'function' => array(HMWP_Classes_ObjController::getClass( 'HMWP_Controllers_Settings' ), 'init'),
            ),
            'hmwp_securitycheck' => array(
                'name' => esc_html__( "Security Check", _HMWP_PLUGIN_NAME_ ),
                'title' => esc_html__("Security Check", _HMWP_PLUGIN_NAME_),
                'capability' => 'hmwp_manage_settings',
                'parent' => 'hmwp_settings',
                'function' => array(HMWP_Classes_ObjController::getClass( 'HMWP_Controllers_SecurityCheck' ), 'init'),
            ),
            'hmwp_backup' => array(
                'name' => esc_html__( "Backup/Restore", _HMWP_PLUGIN_NAME_ ),
                'title' => esc_html__("Backup/Restore", _HMWP_PLUGIN_NAME_),
                'capability' => 'hmwp_manage_settings',
                'parent' => 'hmwp_settings',
                'function' => array(HMWP_Classes_ObjController::getClass( 'HMWP_Controllers_Settings' ), 'init'),
            ),
            'hmwp_advanced' => array(
                'name' => esc_html__( "Advanced", _HMWP_PLUGIN_NAME_ ),
                'title' => __("Advanced Settings", _HMWP_PLUGIN_NAME_),
                'capability' => 'hmwp_manage_settings',
                'parent' => 'hmwp_settings',
                'function' => array(HMWP_Classes_ObjController::getClass( 'HMWP_Controllers_Settings' ), 'init'),
            ),
        );

        foreach ($menu as $key => $value){
            if (in_array($key . '_menu_show', array_keys(HMWP_Classes_Tools::$options))) {
                if (!HMWP_Classes_Tools::getOption($key . '_menu_show')) {
                    unset($menu[$key]);
                }
            }
        }

        if(HMWP_Classes_Tools::getOption('api_token') && apply_filters( 'hmwp_showaccount', true )) {
            $menu['hmwp_account'] = array(
                'name' => esc_html__("My Account", _HMWP_PLUGIN_NAME_),
                'title' => __("My Account", _HMWP_PLUGIN_NAME_),
                'capability' => 'hmwp_manage_settings',
                'parent' => 'hmwp_settings',
                'href' => HMWP_Classes_Tools::getCloudUrl('orders'),
                'function' => false,
            );
        }

        return $menu;
    }

    /**
     * Get the Submenu section for each menu
     * @param $current
     * @return array|mixed
     */
    public function getSubMenu($current) {
        $subtabs = array(
            'hmwp_permalinks' => array(
                array(
                    'title' => esc_html__("Level of Security", _HMWP_PLUGIN_NAME_) . ' ' . '<i class="dashicons-before dashicons-shield-alt text-black-50" style="vertical-align: middle" ></i>',
                    'tab' =>'level',
                ),
                array(
                    'title' => esc_html__("Admin Security", _HMWP_PLUGIN_NAME_),
                    'tab' =>'newadmin',
                ),
                array(
                    'title' => esc_html__("Login Security", _HMWP_PLUGIN_NAME_),
                    'tab' =>'newlogin',
                ),
                array(
                    'title' => esc_html__("Ajax Security", _HMWP_PLUGIN_NAME_),
                    'tab' =>'ajax',
                ),
                array(
                    'title' => esc_html__("User Security", _HMWP_PLUGIN_NAME_),
                    'tab' =>'author',
                ),
                array(
                    'title' => esc_html__("WP Core Security", _HMWP_PLUGIN_NAME_),
                    'tab' =>'core',
                ),
                array(
                    'title' => esc_html__("Plugins Security", _HMWP_PLUGIN_NAME_),
                    'tab' =>'plugin',
                ),
                array(
                    'title' => esc_html__("Themes Security", _HMWP_PLUGIN_NAME_),
                    'tab' =>'theme',
                ),
                array(
                    'title' => esc_html__("API Security", _HMWP_PLUGIN_NAME_),
                    'tab' =>'api',
                ),
                array(
                    'title' => esc_html__("Firewall & Headers", _HMWP_PLUGIN_NAME_),
                    'tab' =>'firewall',
                ),
                array(
                    'title' => esc_html__("Other Options", _HMWP_PLUGIN_NAME_),
                    'tab' =>'more',
                )
            ),
            'hmwp_mapping' => array(
                array(
                    'title' => esc_html__("Text Mapping", _HMWP_PLUGIN_NAME_),
                    'tab' =>'text',
                ),
                array(
                    'title' => esc_html__("URL Mapping", _HMWP_PLUGIN_NAME_),
                    'tab' =>'url',
                ),
                array(
                    'title' => esc_html__("CDN", _HMWP_PLUGIN_NAME_),
                    'tab' =>'cdn',
                ),
                array(
                    'title' => esc_html__("Experimental", _HMWP_PLUGIN_NAME_),
                    'tab' =>'experimental',
                ),
            ),
            'hmwp_tweaks' => array(
                array(
                    'title' => esc_html__("Redirects", _HMWP_PLUGIN_NAME_),
                    'tab' =>'redirects',
                ),
                array(
                    'title' => esc_html__("Feed & Sitemap", _HMWP_PLUGIN_NAME_),
                    'tab' =>'sitemap',
                ),
                array(
                    'title' => esc_html__("Change Options", _HMWP_PLUGIN_NAME_),
                    'tab' =>'changes',
                ),
                array(
                    'title' => esc_html__("Hide Options", _HMWP_PLUGIN_NAME_),
                    'tab' =>'hide',
                ),
                array(
                    'title' => esc_html__("Disable Options", _HMWP_PLUGIN_NAME_),
                    'tab' =>'disable',
                ),
            ),
            'hmwp_brute' => array(
                array(
                    'title' => esc_html__("Blocked IPs Report", _HMWP_PLUGIN_NAME_),
                    'tab' =>'blocked',
                ),
                array(
                    'title' => esc_html__("Brute Force Settings", _HMWP_PLUGIN_NAME_),
                    'tab' =>'brute',
                ),
            ),
            'hmwp_log' => array(
                array(
                    'title' => esc_html__("Events Log Report", _HMWP_PLUGIN_NAME_),
                    'tab' =>'report',
                ),
                array(
                    'title' => esc_html__("Events Log Settings", _HMWP_PLUGIN_NAME_),
                    'tab' =>'log',
                ),

            ),
            'hmwp_advanced' => array(
                array(
                    'title' => esc_html__("Rollback Settings", _HMWP_PLUGIN_NAME_),
                    'tab' =>'rollback',
                ),
                array(
                    'title' => esc_html__("Compatibility", _HMWP_PLUGIN_NAME_),
                    'tab' =>'compatibility',
                ),
//                array(
//                    'title' => esc_html__("Block Detectors", _HMWP_PLUGIN_NAME_),
//                    'tab' =>'block',
//                ),
                array(
                    'title' => esc_html__("Email Notification", _HMWP_PLUGIN_NAME_),
                    'tab' =>'notification',
                ),

            ),
        );

        foreach ($subtabs as $key => &$values) {
            foreach ($values as $index => $value) {
                if (in_array($key . '_' . $value['tab'] . '_show', array_keys(HMWP_Classes_Tools::$options))) {
                    if (!HMWP_Classes_Tools::getOption($key . '_' . $value['tab'] . '_show')) {
                        unset($values[$index]);
                    }
                }
            }
        }

        if(isset( $subtabs[$current])){
            return  $subtabs[$current];
        }
        return array();
    }

    /** @var array with the menu content
     *
     * $page_title (string) (required) The text to be displayed in the title tags of the page when the menu is selected
     * $menu_title (string) (required) The on-screen name text for the menu
     * $capability (string) (required) The capability required for this menu to be displayed to the user. User levels are deprecated and should not be used here!
     * $menu_slug (string) (required) The slug name to refer to this menu by (should be unique for this menu). Prior to Version 3.0 this was called the file (or handle) parameter. If the function parameter is omitted, the menu_slug should be the PHP file that handles the display of the menu page content.
     * $function The function that displays the page content for the menu page. Technically, the function parameter is optional, but if it is not supplied, then WordPress will basically assume that including the PHP file will generate the administration screen, without calling a function. Most plugin authors choose to put the page-generating code in a function within their main plugin file.:In the event that the function parameter is specified, it is possible to use any string for the file parameter. This allows usage of pages such as ?page=my_super_plugin_page instead of ?page=my-super-plugin/admin-options.php.
     * $icon_url (string) (optional) The url to the icon to be used for this menu. This parameter is optional. Icons should be fairly small, around 16 x 16 pixels for best results. You can use the plugin_dir_url( __FILE__ ) function to get the URL of your plugin directory and then add the image filename to it. You can set $icon_url to "div" to have wordpress generate <br> tag instead of <img>. This can be used for more advanced formating via CSS, such as changing icon on hover.
     * $position (integer) (optional) The position in the menu order this menu should appear. By default, if this parameter is omitted, the menu will appear at the bottom of the menu structure. The higher the number, the lower its position in the menu. WARNING: if 2 menu items use the same position attribute, one of the items may be overwritten so that only one item displays!
     *
     * */
    public $menu = array();
    public $meta = array();

    /**
     * Add a menu in WP admin page
     *
     * @param array $param
     *
     * @return void
     */
    public function addMenu($param = null) {
        if ($param)
            $this->menu = $param;

        if (is_array($this->menu)) {

            if ($this->menu[0] <> '' && $this->menu[1] <> '') {

                if (!isset($this->menu[5]))
                    $this->menu[5] = null;
                if (!isset($this->menu[6]))
                    $this->menu[6] = null;

                /* add the menu with WP */
                add_menu_page($this->menu[0], $this->menu[1], $this->menu[2], $this->menu[3], $this->menu[4], $this->menu[5], $this->menu[6]);
            }
        }
    }

    /**
     * Add a submenumenu in WP admin page
     *
     * @param array $param
     *
     * @return void
     */
    public function addSubmenu($param = null) {
        if ($param)
            $this->menu = $param;

        if (is_array($this->menu)) {

            if ($this->menu[0] <> '' && $this->menu[1] <> '') {

                if (!isset($this->menu[5]))
                    $this->menu[5] = null;
                if (!isset($this->menu[6]))
                    $this->menu[6] = null;

                /* add the menu with WP */
                add_submenu_page($this->menu[0], $this->menu[1], $this->menu[2], $this->menu[3], $this->menu[4], $this->menu[5], $this->menu[6]);
            }
        }
    }

    /**
     * Add a box Meta in WP
     *
     * @param array $param
     *
     * @return void
     */
    public function addOption($param = null) {
        if ($param) {
            $this->meta = $param;
        }

        if (is_array($this->meta)) {

            if ($this->meta[0] <> '' && $this->meta[1] <> '') {

                /* add the box content with WP */
                add_options_page($this->meta[0], $this->meta[1], $this->meta[2], $this->meta[3], $this->meta[4]);
            }
        }
    }

    public function addSettingsClass( $classes ){
        if ($page = HMWP_Classes_Tools::getValue('page', false)) {

            $menu = $this->getMenu();
            if(in_array($page,array_keys($menu))){
                $classes = "$classes hmwp-settings";
            }

        }

        return $classes;
    }



    public function fixEnqueueErrors() {

        $exclude = array('boostrap',
            'wpcd-admin-js', 'ampforwp_admin_js', '__ytprefs_admin__', 'wpf-graphics-admin-style',
            'wwp-bootstrap', 'wwp-bootstrap-select', 'wwp-popper', 'wwp-script',
            'wpf_admin_style', 'wpf_bootstrap_script', 'wpf_wpfb-front_script', 'auxin-admin-style',
            'wdc-styles-extras', 'wdc-styles-main', 'wp-color-picker-alpha',  //collor picker compatibility
            'td_wp_admin', 'td_wp_admin_color_picker', 'td_wp_admin_panel', 'td_edit_page', 'td_page_options', 'td_tooltip', 'td_confirm', 'thickbox',
            'font-awesome', 'bootstrap-iconpicker-iconset', 'bootstrap-iconpicker'
        );

        foreach ($exclude as $name) {
            wp_dequeue_script($name);
            wp_dequeue_style($name);
        }
    }

}
