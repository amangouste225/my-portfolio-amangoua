<div class="card col-sm-12 m-0  mb-2 p-0 rounded-0">
    <div class="card-body f-gray-dark text-center">
        <h3 class="card-title"><?php echo esc_html__( 'Check Frontend URLs', _HMWP_PLUGIN_NAME_ ); ?></h3>
        <div class="border-top mt-3 pt-3"></div>
        <div class="card-text text-muted">
            <?php echo esc_html__( 'Check if your website is working with the current configuration.', _HMWP_PLUGIN_NAME_ ) ?>
        </div>
        <div class="card-text text-info m-3">
            <button type="button" class="btn rounded-0 btn-default btn-sm text-white px-4 frontend_test hmwp_modal" data-remote="<?php echo home_url() . '?hmwp_preview=1&rnd=' . mt_rand(11111,99999) ?>" data-target="#frontend_test_modal" ><?php echo esc_html__( 'Check Home Page', _HMWP_PLUGIN_NAME_ ); ?></button>
            <button type="button" class="btn rounded-0 btn-default btn-sm text-white px-4 frontend_test hmwp_modal" data-remote="<?php echo site_url(HMWP_Classes_Tools::getOption( 'hmwp_wp-json' )) . '?hmwp_preview=1&rnd=' . mt_rand(11111,99999) ?>" data-target="#frontend_test_modal" ><?php echo esc_html__( 'Check REST API', _HMWP_PLUGIN_NAME_ ); ?></button>
        </div>
    </div>
</div>
<div class="modal" id="frontend_test_modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo esc_html__( 'Frontend Test', _HMWP_PLUGIN_NAME_ ); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="min-height: 500px;">
                <div>Home Page: </div>
            </div>
        </div>
    </div>
</div>
