<div id="hmwp_wrap" class="d-flex flex-row p-0 my-3">
    <div class="hmwp_row d-flex flex-row p-0 m-0">
        <div class="hmwp_col flex-grow-1 px-0 py-0 mr-3 mb-3 bg-white">
            <h3 class="card-title hmwp_header p-2 m-0"><?php echo esc_html__( 'Recommended Plugins', _HMWP_PLUGIN_NAME_ ); ?></h3>

            <div class="row row-cols-1 row-cols-md-3 px-1 mx-1" style="max-width: 1200px;">
                <?php foreach ($view->plugins as $name => $plugin) { ?>
                    <div class="col px-2 py-0 mb-5">
                        <div class="card h-100 p-0 shadow-0 rounded-0">
                            <div class="card-body m-0 p-0">
                                <h3 class="card-title my-2 p-2"><a href="<?php echo $plugin['url']; ?>" class="text-link" target="_blank"><?php echo $plugin['title']; ?></a></h3>
                                <div class="card-text">
                                    <a href="<?php echo $plugin['url']; ?>" target="_blank">
                                        <img class="col-sm-12 p-0" src="<?php echo $plugin['banner']; ?>"  style="min-height: 100px;">
                                    </a>
                                </div>
                                <div class="card-text small text-secondary my-2  p-2" style="min-height: 120px;"><?php echo $plugin['description']; ?></div>

                            </div>
                            <div class="card-footer text-right">
                                <a href="<?php echo $plugin['url']; ?>" class="btn rounded-0 btn-light" target="_blank"><?php echo esc_html__('More details', _HMWP_PLUGIN_NAME_) ?></a>
                                <?php if (!HMWP_Classes_Tools::isPluginActive($plugin['path'])) { ?>
                                    <a href="<?php echo $plugin['url']; ?>" target="_blank" class="btn rounded-0 btn-default text-white"><?php echo esc_html__('Go To Plugin', _HMWP_PLUGIN_NAME_) ?></a>
                                <?php } else { ?>
                                    <button class="btn rounded-0 plugin btn-light" disabled><?php echo esc_html__('Plugin Active', _HMWP_PLUGIN_NAME_) ?></button>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
        <div class="hmwp_col hmwp_col_side p-0 m-0 mr-2">
            <div class="card col-sm-12 m-0 p-0 rounded-0">
                <div class="card-body f-gray-dark text-left">
                    <h3 class="panel-title"><?php echo esc_html__('Plugins', _HMWP_PLUGIN_NAME_); ?></h3>
                    <div class="text-info mt-3"><?php echo sprintf(__("We test the latest versions of the plugins listed here every week to <strong>ensure they work with the %s plugin perfectly</strong>.
                     <br /><br />You don't need to add all these plugins to your website. If you're already using a cache plugin, you don't need to install another one. <strong>We recommend only using one cache plugin</strong>.
                     <br /><br />You can also install either the <strong>iThemes Security</strong> plugin or the <strong>Sucuri Security</strong> plugin to work with the %s plugin.", _HMWP_PLUGIN_NAME_), HMWP_Classes_Tools::getOption('hmwp_plugin_name'), HMWP_Classes_Tools::getOption('hmwp_plugin_name')); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>