<noscript> <style>#hmwp_wrap .tab-panel:not(.tab-panel-first){display: block}</style> </noscript>
<div id="hmwp_wrap" class="d-flex flex-row p-0 my-3">
<?php echo $view->getAdminTabs(HMWP_Classes_Tools::getValue('page', 'hmwp_brute')); ?>
    <div class="hmwp_row d-flex flex-row p-0 m-0">
        <div class="hmwp_col flex-grow-1 px-3 py-3 mr-2 mb-3 bg-white">

            <div id="blocked" class="card col-sm-12 p-0 m-0 tab-panel tab-panel-first">
                <h3 class="card-title hmwp_header p-2 m-0"><?php echo esc_html__('Blocked IPs', _HMWP_PLUGIN_NAME_); ?>
                    <a href="<?php echo HMWP_Classes_Tools::getOption('hmwp_plugin_website') ?>/kb/brute-force-attack-protection/#block_ip_report" target="_blank" class="d-inline-block ml-2" style="color: white"><i class="dashicons dashicons-editor-help"></i></a>
                </h3>
                <div class="card-body">
                    <?php if (HMWP_Classes_Tools::getOption( 'hmwp_bruteforce' ) ){ ?>
                        <div class="mt-3 mb-1" style="display: block;">
                            <div class="py-1">
                                <div class="float-right my-1" onclick="jQuery('#hmwp_blockedips_form').submit()"><i class="dashicons dashicons-update" style="cursor: pointer"></i></div>
                                <div class="my-1">
                                    <form method="POST">
                                        <?php wp_nonce_field('hmwp_deleteallips', 'hmwp_nonce') ?>
                                        <input type="hidden" name="action" value="hmwp_deleteallips"/>
                                        <button type="submit" class="btn rounded-0 btn-default save py-1"><?php echo esc_html__('Unlock all', _HMWP_PLUGIN_NAME_); ?></button>
                                    </form>
                                </div>

                            </div>
                            <form id="hmwp_blockedips_form" method="POST">
                                <?php wp_nonce_field( 'hmwp_blockedips', 'hmwp_nonce' ) ?>
                                <input type="hidden" name="action" value="hmwp_blockedips"/>
                            </form>
                            <div id="hmwp_blockedips" class="col-sm-12 p-0"></div>
                        </div>
                    <?php }else{ ?>
                        <div class="col-sm-12 p-1 text-center">
                            <div class="text-black-50 mb-2"><?php echo esc_html__( 'Activate the "Brute Force" option to see the user IP blocked report', _HMWP_PLUGIN_NAME_ ); ?></div>
                            <a href="#brute" class="btn btn-default hmwp_nav_item" data-tab="brute"><?php echo esc_html__( 'Activate Brute Force Protection', _HMWP_PLUGIN_NAME_ ); ?></a>
                        </div>
                    <?php } ?>
                </div>
            </div>

            <form method="POST">
                <?php wp_nonce_field('hmwp_brutesettings', 'hmwp_nonce') ?>
                <input type="hidden" name="action" value="hmwp_brutesettings"/>

                <div id="brute" class="card col-sm-12 p-0 m-0 tab-panel ">
                    <h3 class="card-title hmwp_header p-2 m-0"><?php echo esc_html__('Brute Force', _HMWP_PLUGIN_NAME_); ?></h3>
                    <div class="card-body">
                        <div class="col-sm-12 row mb-1 py-1 mx-2 ">
                            <div class="checker col-sm-12 row my-2 py-1">
                                <div class="col-sm-12 p-0 switch switch-sm">
                                    <input type="checkbox" id="hmwp_bruteforce" name="hmwp_bruteforce" class="switch" <?php echo(HMWP_Classes_Tools::getOption('hmwp_bruteforce') ? 'checked="checked"' : '') ?> value="1"/>
                                    <label for="hmwp_bruteforce"><?php echo esc_html__('Use Brute Force Protection', _HMWP_PLUGIN_NAME_); ?></label>
                                    <a href="<?php echo HMWP_Classes_Tools::getOption('hmwp_plugin_website') ?>/kb/brute-force-attack-protection/#activate_brute_force" target="_blank" class="d-inline-block ml-2" ><i class="dashicons dashicons-editor-help"></i></a>
                                    <div class="offset-1 text-black-50"><?php echo esc_html__('Protects your website against Brute Force login attacks.', _HMWP_PLUGIN_NAME_); ?></div>
                                </div>
                            </div>
                        </div>

                        <?php if ( HMWP_Classes_Tools::isPluginActive( 'woocommerce/woocommerce.php' ) ) { ?>
                            <div class="col-sm-12 row mb-1 py-1 mx-2 hmwp_bruteforce">
                                <div class="checker col-sm-12 row my-2 py-1">
                                    <div class="col-sm-12 p-0 switch switch-sm">
                                        <input type="checkbox" id="hmwp_bruteforce_woocommerce" name="hmwp_bruteforce_woocommerce" class="switch" <?php echo(HMWP_Classes_Tools::getOption('hmwp_bruteforce_woocommerce') ? 'checked="checked"' : '') ?> value="1"/>
                                        <label for="hmwp_bruteforce_woocommerce"><?php echo esc_html__('Add WooCommerce Login Protection', _HMWP_PLUGIN_NAME_); ?></label>
                                        <div class="offset-1 text-black-50"><?php echo esc_html__('Activate the Brute Force protection for Woocommerce login forms.', _HMWP_PLUGIN_NAME_); ?></div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="hmwp_bruteforce">

                            <div class="border-top"></div>
                            <input type="hidden" value="<?php echo(HMWP_Classes_Tools::getOption('brute_use_math') ? '1' : '0') ?>" name="brute_use_math">
                            <input type="hidden" value="<?php echo(HMWP_Classes_Tools::getOption('brute_use_captcha') ? '1' : '0') ?>" name="brute_use_captcha">
                            <input type="hidden" value="<?php echo(HMWP_Classes_Tools::getOption('brute_use_captcha_v3') ? '1' : '0') ?>" name="brute_use_captcha_v3">

                            <div class="col-sm-12 group_autoload d-flex justify-content-center btn-group btn-group-lg mt-3 px-0" role="group" >
                                <button type="button" class="btn btn-outline-info brute_use_math mx-1 py-4 px-4 <?php echo(HMWP_Classes_Tools::getOption('brute_use_math') ? 'active' : '') ?>"><?php echo esc_html__('Math reCAPTCHA', _HMWP_PLUGIN_NAME_); ?></button>
                                <button type="button" class="btn btn-outline-info brute_use_captcha mx-1 py-4 px-4 <?php echo(HMWP_Classes_Tools::getOption('brute_use_captcha') ? 'active' : '') ?>"><?php echo esc_html__("Google reCAPTCHA V2", _HMWP_PLUGIN_NAME_) ?></button>
                                <button type="button" class="btn btn-outline-info brute_use_captcha_v3 mx-1 py-4 px-4 <?php echo(HMWP_Classes_Tools::getOption('brute_use_captcha_v3') ? 'active' : '') ?>"><?php echo esc_html__("Google reCAPTCHA V3", _HMWP_PLUGIN_NAME_) ?></button>
                            </div>

                            <div class="brute_use_captcha" <?php echo(!HMWP_Classes_Tools::getOption('brute_use_captcha') ? 'style="display:none"' : '') ?>>
                                <div class="col-sm-12 text-center border-bottom border-light py-3 mx-0 my-3">
                                    <?php echo sprintf(__("%sClick here%s to create or view keys for Google reCAPTCHA v2.", _HMWP_PLUGIN_NAME_), '<a href="https://www.google.com/recaptcha/admin/create" class="mx-1 text-link font-weight-bold text-uppercase" target="_blank">', '</a>'); ?>
                                </div>
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-md-4 p-0 font-weight-bold">
                                        <?php echo esc_html__('Site key', _HMWP_PLUGIN_NAME_); ?>:
                                        <div class="small text-black-50"><?php echo sprintf(__("Site keys for %sGoogle reCaptcha%s.", _HMWP_PLUGIN_NAME_), '<a href="https://www.google.com/recaptcha/admin#list" class="text-link" target="_blank">', '</a>'); ?></div>
                                    </div>
                                    <div class="col-md-8 p-0 input-group">
                                        <input type="text" class="form-control bg-input" name="brute_captcha_site_key" value="<?php echo HMWP_Classes_Tools::getOption('brute_captcha_site_key') ?>"/>
                                    </div>
                                </div>
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-md-4 p-0 font-weight-bold">
                                        <?php echo esc_html__('Secret Key', _HMWP_PLUGIN_NAME_); ?>:
                                        <div class="small text-black-50"><?php echo sprintf(__("Secret keys for %sGoogle reCAPTCHA%s.", _HMWP_PLUGIN_NAME_), '<a href="https://www.google.com/recaptcha/admin#list" class="text-link" target="_blank">', '</a>'); ?></div>
                                    </div>
                                    <div class="col-md-8 p-0 input-group">
                                        <input type="text" class="form-control bg-input" name="brute_captcha_secret_key" value="<?php echo HMWP_Classes_Tools::getOption('brute_captcha_secret_key') ?>"/>
                                    </div>
                                </div>
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-sm-4 p-1">
                                        <div class="font-weight-bold"><?php echo esc_html__('reCaptcha Theme', _HMWP_PLUGIN_NAME_); ?>:</div>
                                    </div>
                                    <div class="col-sm-8 p-0 input-group">
                                        <select name="brute_captcha_theme" class="form-control bg-input mb-1">
                                            <?php
                                            $themes = array(esc_html__('light', _HMWP_PLUGIN_NAME_), esc_html__('dark', _HMWP_PLUGIN_NAME_));
                                            foreach ($themes as $theme) {
                                                echo '<option value="' . $theme . '" ' . selected($theme, HMWP_Classes_Tools::getOption('brute_captcha_theme'), true) . '>' . ucfirst($theme) . '</option>';
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-sm-4 p-1">
                                        <div class="font-weight-bold"><?php echo esc_html__('reCaptcha Language', _HMWP_PLUGIN_NAME_); ?>:</div>
                                    </div>
                                    <div class="col-sm-8 p-0 input-group">
                                        <select name="brute_captcha_language" class="form-control bg-input mb-1">
                                            <?php
                                            $languages = array(
                                                esc_html__('Auto Detect', _HMWP_PLUGIN_NAME_) => '',
                                                esc_html__('English', _HMWP_PLUGIN_NAME_) => 'en',
                                                esc_html__('Arabic', _HMWP_PLUGIN_NAME_) => 'ar',
                                                esc_html__('Bulgarian', _HMWP_PLUGIN_NAME_) => 'bg',
                                                esc_html__('Catalan Valencian', _HMWP_PLUGIN_NAME_) => 'ca',
                                                esc_html__('Czech', _HMWP_PLUGIN_NAME_) => 'cs',
                                                esc_html__('Danish', _HMWP_PLUGIN_NAME_) => 'da',
                                                esc_html__('German', _HMWP_PLUGIN_NAME_) => 'de',
                                                esc_html__('Greek', _HMWP_PLUGIN_NAME_) => 'el',
                                                esc_html__('British English', _HMWP_PLUGIN_NAME_) => 'en_gb',
                                                esc_html__('Spanish', _HMWP_PLUGIN_NAME_) => 'es',
                                                esc_html__('Persian', _HMWP_PLUGIN_NAME_) => 'fa',
                                                esc_html__('French', _HMWP_PLUGIN_NAME_) => 'fr',
                                                esc_html__('Canadian French', _HMWP_PLUGIN_NAME_) => 'fr_ca',
                                                esc_html__('Hindi', _HMWP_PLUGIN_NAME_) => 'hi',
                                                esc_html__('Croatian', _HMWP_PLUGIN_NAME_) => 'hr',
                                                esc_html__('Hungarian', _HMWP_PLUGIN_NAME_) => 'hu',
                                                esc_html__('Indonesian', _HMWP_PLUGIN_NAME_) => 'id',
                                                esc_html__('Italian', _HMWP_PLUGIN_NAME_) => 'it',
                                                esc_html__('Hebrew', _HMWP_PLUGIN_NAME_) => 'iw',
                                                esc_html__('Jananese', _HMWP_PLUGIN_NAME_) => 'ja',
                                                esc_html__('Korean', _HMWP_PLUGIN_NAME_) => 'ko',
                                                esc_html__('Lithuanian', _HMWP_PLUGIN_NAME_) => 'lt',
                                                esc_html__('Latvian', _HMWP_PLUGIN_NAME_) => 'lv',
                                                esc_html__('Dutch', _HMWP_PLUGIN_NAME_) => 'nl',
                                                esc_html__('Norwegian', _HMWP_PLUGIN_NAME_) => 'no',
                                                esc_html__('Polish', _HMWP_PLUGIN_NAME_) => 'pl',
                                                esc_html__('Portuguese', _HMWP_PLUGIN_NAME_) => 'pt',
                                                esc_html__('Romanian', _HMWP_PLUGIN_NAME_) => 'ro',
                                                esc_html__('Russian', _HMWP_PLUGIN_NAME_) => 'ru',
                                                esc_html__('Slovak', _HMWP_PLUGIN_NAME_) => 'sk',
                                                esc_html__('Slovene', _HMWP_PLUGIN_NAME_) => 'sl',
                                                esc_html__('Serbian', _HMWP_PLUGIN_NAME_) => 'sr',
                                                esc_html__('Swedish', _HMWP_PLUGIN_NAME_) => 'sv',
                                                esc_html__('Thai', _HMWP_PLUGIN_NAME_) => 'th',
                                                esc_html__('Turkish', _HMWP_PLUGIN_NAME_) => 'tr',
                                                esc_html__('Ukrainian', _HMWP_PLUGIN_NAME_) => 'uk',
                                                esc_html__('Vietnamese', _HMWP_PLUGIN_NAME_) => 'vi',
                                                esc_html__('Simplified Chinese', _HMWP_PLUGIN_NAME_) => 'zh_cn',
                                                esc_html__('Traditional Chinese', _HMWP_PLUGIN_NAME_) => 'zh_tw'
                                            );
                                            foreach ($languages as $key => $language) {
                                                echo '<option value="' . $language . '"  ' . selected($language, HMWP_Classes_Tools::getOption('brute_captcha_language'), true) . '>' . ucfirst($key) . '</option>';
                                            } ?>
                                        </select>
                                    </div>
                                </div>

                                <?php if (HMWP_Classes_Tools::getOption('brute_captcha_site_key') <> '' && HMWP_Classes_Tools::getOption('brute_captcha_secret_key') <> '') { ?>
                                    <div class="col-sm-12 border-bottom border-light py-3 mx-0 my-3">
                                        <button type="button" class="btn btn-lg btn-default brute_recaptcha_test hmwp_modal" data-remote="<?php echo site_url('wp-login.php') ?>" data-target="#brute_recaptcha_modal" ><?php echo esc_html__('reCAPTCHA V2 Test', _HMWP_PLUGIN_NAME_); ?></button>

                                        <h4 class="mt-5 mb-3"><?php echo esc_html__('Next Steps', _HMWP_PLUGIN_NAME_); ?></h4>
                                        <ol>
                                            <li><?php echo sprintf(__("Run %sreCAPTCHA Test%s and login inside the popup.", _HMWP_PLUGIN_NAME_), '<strong>', '</strong>'); ?></li>
                                            <li><?php echo esc_html__("If you're able to login, you've set reCAPTCHA correctly.", _HMWP_PLUGIN_NAME_); ?></li>
                                            <li><?php echo esc_html__('If the reCAPTCHA displays any error, please make sure you fix them before moving forward.', _HMWP_PLUGIN_NAME_); ?></li>
                                            <li><?php echo esc_html__('Do not logout from your account until you are confident that reCAPTCHA is working and you will be able to login again.', _HMWP_PLUGIN_NAME_); ?></li>
                                            <li><?php echo esc_html__("If you can't configure reCAPTCHA, switch to Math reCaptcha protection.", _HMWP_PLUGIN_NAME_); ?></li>
                                        </ol>
                                    </div>
                                <?php } ?>

                            </div>
                            <div class="brute_use_captcha_v3" <?php echo(!HMWP_Classes_Tools::getOption('brute_use_captcha_v3') ? 'style="display:none"' : '') ?>>
                                <div class="col-sm-12 text-center border-bottom border-light py-3 mx-0 my-3">
                                    <?php echo sprintf(__("%sClick here%s to create or view keys for Google reCAPTCHA v3.", _HMWP_PLUGIN_NAME_), '<a href="https://www.google.com/recaptcha/admin/create" class="mx-1 text-link font-weight-bold text-uppercase" target="_blank">', '</a>'); ?>
                                </div>
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-md-4 p-0 font-weight-bold">
                                        <?php echo esc_html__('Site key', _HMWP_PLUGIN_NAME_); ?>:
                                        <div class="small text-black-50"><?php echo sprintf(__("Site keys for %sGoogle reCaptcha%s.", _HMWP_PLUGIN_NAME_), '<a href="https://www.google.com/recaptcha/admin#list" class="text-link" target="_blank">', '</a>'); ?></div>
                                    </div>
                                    <div class="col-md-8 p-0 input-group">
                                        <input type="text" class="form-control bg-input" name="brute_captcha_site_key_v3" value="<?php echo HMWP_Classes_Tools::getOption('brute_captcha_site_key_v3') ?>"/>
                                    </div>
                                </div>
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-md-4 p-0 font-weight-bold">
                                        <?php echo esc_html__('Secret Key', _HMWP_PLUGIN_NAME_); ?>:
                                        <div class="small text-black-50"><?php echo sprintf(__("Secret keys for %sGoogle reCAPTCHA%s.", _HMWP_PLUGIN_NAME_), '<a href="https://www.google.com/recaptcha/admin#list" class="text-link" target="_blank">', '</a>'); ?></div>
                                    </div>
                                    <div class="col-md-8 p-0 input-group">
                                        <input type="text" class="form-control bg-input" name="brute_captcha_secret_key_v3" value="<?php echo HMWP_Classes_Tools::getOption('brute_captcha_secret_key_v3') ?>"/>
                                    </div>
                                </div>

                                <?php if (HMWP_Classes_Tools::getOption('brute_captcha_site_key_v3') <> '' && HMWP_Classes_Tools::getOption('brute_captcha_secret_key_v3') <> '') { ?>
                                    <div class="col-sm-12 border-bottom border-light py-3 mx-0 my-3">
                                        <button type="button" class="btn btn-lg btn-default brute_recaptcha_test hmwp_modal" data-remote="<?php echo site_url('wp-login.php') ?>" data-target="#brute_recaptcha_modal" ><?php echo esc_html__('reCAPTCHA V3 Test', _HMWP_PLUGIN_NAME_); ?></button>

                                        <h4 class="mt-5 mb-3"><?php echo esc_html__('Next Steps', _HMWP_PLUGIN_NAME_); ?></h4>
                                        <ol>
                                            <li><?php echo sprintf(__("Run %sreCAPTCHA Test%s and login inside the popup.", _HMWP_PLUGIN_NAME_), '<strong>', '</strong>'); ?></li>
                                            <li><?php echo esc_html__("If you're able to login, you've set reCAPTCHA correctly.", _HMWP_PLUGIN_NAME_); ?></li>
                                            <li><?php echo esc_html__('If the reCAPTCHA displays any error, please make sure you fix them before moving forward.', _HMWP_PLUGIN_NAME_); ?></li>
                                            <li><?php echo esc_html__('Do not logout from your account until you are confident that reCAPTCHA is working and you will be able to login again.', _HMWP_PLUGIN_NAME_); ?></li>
                                            <li><?php echo esc_html__("If you can't configure reCAPTCHA, switch to Math reCaptcha protection.", _HMWP_PLUGIN_NAME_); ?></li>
                                        </ol>
                                    </div>
                                <?php } ?>

                            </div>
                            <div>
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-md-4 p-0 font-weight-bold">
                                        <?php echo esc_html__('Max fail attempts', _HMWP_PLUGIN_NAME_); ?>:
                                        <div class="small text-black-50"><?php echo esc_html__('Block IP on login page', _HMWP_PLUGIN_NAME_); ?></div>
                                    </div>
                                    <div class="col-md-2 p-0 input-group">
                                        <input type="text" class="form-control bg-input" name="brute_max_attempts" value="<?php echo HMWP_Classes_Tools::getOption('brute_max_attempts') ?>"/>
                                    </div>
                                </div>
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-md-4 p-0 font-weight-bold">
                                        <?php echo esc_html__('Ban duration', _HMWP_PLUGIN_NAME_); ?>:
                                        <div class="small text-black-50"><?php echo esc_html__('No. of seconds', _HMWP_PLUGIN_NAME_); ?></div>
                                    </div>
                                    <div class="col-md-2 p-0 input-group input-group">
                                        <input type="text" class="form-control bg-input" name="brute_max_timeout" value="<?php echo HMWP_Classes_Tools::getOption('brute_max_timeout') ?>"/>
                                    </div>
                                </div>
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-md-4 p-0 font-weight-bold">
                                        <?php echo esc_html__('Lockout Message', _HMWP_PLUGIN_NAME_); ?>:
                                        <div class="small text-black-50"><?php echo esc_html__('Show message instead of login form', _HMWP_PLUGIN_NAME_); ?></div>
                                    </div>
                                    <div class="col-md-8 p-0 input-group input-group">
                                        <textarea type="text" class="form-control bg-input" name="hmwp_brute_message" style="height: 80px"><?php echo HMWP_Classes_Tools::getOption('hmwp_brute_message') ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="modal" id="brute_recaptcha_modal" tabindex="-1" role="dialog" aria-hidden="true">
                                <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel"><?php echo esc_html__('reCAPTCHA Test', _HMWP_PLUGIN_NAME_); ?></h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <iframe class="modal-body" style="min-height: 500px;"></iframe>
                                    </div>
                                </div>
                            </div>

                            <div class="border-top">
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-md-4 p-0 font-weight-bold">
                                        <?php echo esc_html__('Whitelist IPs', _HMWP_PLUGIN_NAME_); ?>:
                                        <a href="<?php echo HMWP_Classes_Tools::getOption('hmwp_plugin_website') ?>/kb/brute-force-attack-protection/#whitelist_ip_address" target="_blank" class="d-inline-block ml-2" ><i class="dashicons dashicons-editor-help"></i></a>
                                        <div class="small text-black-50"><?php echo sprintf(__('You can white-list a single IP like 192.168.0.1 or a range of 245 IPs like 192.168.0.*. Find your IP with %s', _HMWP_PLUGIN_NAME_), '<a href="https://whatismyipaddress.com/" target="_blank">https://whatismyipaddress.com/</a>') ?></div>
                                    </div>
                                    <div class="col-md-8 p-0 input-group input-group">
                                        <?php
                                        $ips = array();
                                        if (HMWP_Classes_Tools::getOption('whitelist_ip')) {
                                            $ips = json_decode(HMWP_Classes_Tools::getOption('whitelist_ip'), true);
                                        }
                                        ?>
                                        <textarea type="text" class="form-control bg-input" name="whitelist_ip" style="height: 100px"><?php echo(!empty($ips) ? implode(PHP_EOL, $ips) : '') ?></textarea>
                                    </div>
                                </div>
                                <div class="col-sm-12 row border-bottom border-light py-3 mx-0 my-3">
                                    <div class="col-md-4 p-0 font-weight-bold">
                                        <?php echo esc_html__('Ban IPs', _HMWP_PLUGIN_NAME_); ?>:
                                        <a href="<?php echo HMWP_Classes_Tools::getOption('hmwp_plugin_website') ?>/kb/brute-force-attack-protection/#ban_ip_address" target="_blank" class="d-inline-block ml-2" ><i class="dashicons dashicons-editor-help"></i></a>
                                        <div class="small text-black-50"><?php echo esc_html__('You can ban a single IP like 192.168.0.1 or a range of 245 IPs like 192.168.0.*. These IPs will not be able to access the login page.', _HMWP_PLUGIN_NAME_) ?></div>
                                    </div>
                                    <div class="col-md-8 p-0 input-group input-group">
                                        <?php
                                        $ips = array();
                                        if (HMWP_Classes_Tools::getOption('banlist_ip')) {
                                            $ips = json_decode(HMWP_Classes_Tools::getOption('banlist_ip'), true);
                                        }
                                        ?>
                                        <textarea type="text" class="form-control bg-input" name="banlist_ip" style="height: 100px"><?php echo(!empty($ips) ? implode(PHP_EOL, $ips) : '') ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

                <div class="col-sm-12 m-0 p-2 bg-light text-center" style="position: fixed; bottom: 0; right: 0; z-index: 100; box-shadow: 0px 0px 8px -3px #444;">
                    <button type="submit" class="btn rounded-0 btn-success px-5 mr-5 save"><?php echo esc_html__( 'Save', _HMWP_PLUGIN_NAME_ ); ?></button>
                </div>
            </form>

        </div>
        <div class="hmwp_col hmwp_col_side p-0 m-0 mr-2">
            <div class="card col-sm-12 m-0 p-0 rounded-0">
                <div class="card-body f-gray-dark text-left">
                    <h3 class="card-title"><?php echo esc_html__('Brute Force Login Protection', _HMWP_PLUGIN_NAME_); ?></h3>
                    <div class="text-info"><?php echo sprintf(esc_html__("Protects your website against Brute Force login attacks using %s A common threat web developers face is a password-guessing attack known as a Brute Force attack. A Brute Force attack is an attempt to discover a password by systematically trying every possible combination of letters, numbers, and symbols until you discover the one correct combination that works.", _HMWP_PLUGIN_NAME_),HMWP_Classes_Tools::getOption('hmwp_plugin_name') . '<br><br>'); ?>
                    </div>
                </div>
            </div>
            <div class="card col-sm-12 p-0">
                <div class="card-body f-gray-dark text-left border-bottom">
                    <h3 class="card-title"><?php echo esc_html__('Features', _HMWP_PLUGIN_NAME_); ?></h3>
                    <ul class="text-info" style="margin-left: 16px; list-style: circle;">
                        <li><?php echo esc_html__("Limit the number of allowed login attempts using normal login form.", _HMWP_PLUGIN_NAME_); ?></li>
                        <li><?php echo esc_html__("Math & Google reCaptcha verification while logging in.", _HMWP_PLUGIN_NAME_); ?></li>
                        <li><?php echo esc_html__("Manually block/unblock IP addresses.", _HMWP_PLUGIN_NAME_); ?></li>
                        <li><?php echo esc_html__("Manually whitelist trusted IP addresses.", _HMWP_PLUGIN_NAME_); ?></li>
                        <li><?php echo esc_html__("Option to inform user about remaining attempts on login page.", _HMWP_PLUGIN_NAME_); ?></li>
                        <li><?php echo esc_html__("Custom message to show to blocked users.", _HMWP_PLUGIN_NAME_); ?></li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
</div>
