<div class="hmwp_notice <?php echo $type ?>">
    <?php echo $message ?>

    <?php if($type == 'notice'){ ?>
        <?php $url = add_query_arg( array('hmwp_nonce' => wp_create_nonce( 'hmwp_ignoreerror' ), 'action' => 'hmwp_ignoreerror', 'hash' => md5($message)) );  ?>
        <a href="<?php echo $url?>"  style="float: right; color: gray; text-decoration: underline; font-size: 0.8rem;"><?php echo esc_html__('ignore alert', _HMWP_PLUGIN_NAME_)?></a>
    <?php }?>
</div>
