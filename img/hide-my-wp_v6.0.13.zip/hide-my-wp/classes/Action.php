<?php
defined('ABSPATH') || die('Cheatin\' uh?');

/**
 * Set the ajax action and call for wordpress
 */
class HMWP_Classes_Action extends HMWP_Classes_FrontController {

    /** @var array with all form and ajax actions */
    var $actions = array();

    /** @var array from core config */
    private static $config;


    /**
     * The hookAjax is loaded as custom hook in hookController class
     *
     * @return void
     * @throws Exception
     */
    public function hookInit() {
        if (HMWP_Classes_Tools::isAjax()) {
            $this->getActions(true);
        }
    }

    /**
     * The hookSubmit is loaded when action si posted
     *
     * @throws Exception
     * @return void
     */
    function hookMenu() {
        /* Only if post */
        if (!HMWP_Classes_Tools::isAjax()) {
            $this->getActions();
        }
    }

    /**
     * Hook the Multisite Menu
     * @throws Exception
     */
    function hookMultisiteMenu() {
        /* Only if post */
        if (!HMWP_Classes_Tools::isAjax()) {
            $this->getActions();
        }
    }

    /**
     * Get the list with all the plugin actions
     * @return array
     */
    public function getActionsTable(){
       return array(
            array(
                "name" => "HMWP_Controllers_Settings",
                "actions" => array(
                    "action" => array(
                        "hmwp_settings",
                        "hmwp_tweakssettings",
                        "hmwp_confirm",
                        "hmwp_newpluginschange",
                        "hmwp_abort",
                        "hmwp_ignore_errors",
                        "hmwp_restore_settings",
                        "hmwp_manualrewrite",
                        "hmwp_mappsettings",
                        "hmwp_advsettings",
                        "hmwp_devsettings",
                        "hmwp_devdownload",
                        "hmwp_changepathsincache",
                        "hmwp_savecachepath",
                        "hmwp_backup",
                        "hmwp_restore",
                        "hmwp_rollback",
                        "hmwp_download_settings"
                    )
                ),
            ),
            array(
                "name" => "HMWP_Controllers_Overview",
                "actions" => array(
                    "action" => array(
                        "hmwp_feature_save"
                    )
                ),
            ),
            array(
                "name" => "HMWP_Controllers_SecurityCheck",
                "actions" => array(
                    "action" => array(
                        "hmwp_securitycheck",
                        "hmwp_fixsettings",
                        "hmwp_fixconfig",
                        "hmwp_securityexclude",
                        "hmwp_resetexclude"
                    )
                ),
            ),
            array(
                "name" => "HMWP_Controllers_Brute",
                "actions" => array(
                    "action" => array(
                        "hmwp_brutesettings",
                        "hmwp_blockedips",
                        "hmwp_deleteip",
                        "hmwp_deleteallips"
                    )
                ),
            ),
            array(
                "name" => "HMWP_Controllers_Log",
                "actions" => array(
                    "action" => array(
                        "hmwp_logsettings"
                    )
                ),
            ),
            array(
                "name" => "HMWP_Controllers_Widget",
                "actions" => array(
                    "action" => "hmwp_widget_securitycheck"
                ),
            ),
           array(
               "name" => "HMWP_Controllers_Connect",
               "actions" => array(
                   "action" => array(
                       "hmwp_connect"
                   )
               ),
           ),
           array(
               "name" => "HMWP_Classes_Error",
               "actions" => array(
                   "action" => array(
                       "hmwp_ignoreerror"
                   )
               ),
           ),
        );
    }


    /**
     * Get all actions from config.json in core directory and add them in the WP
     *
     * @param bool $ajax
     * @throws Exception
     */
    public function getActions($ajax = false) {

        if ( ! is_admin() && ! is_network_admin() ) {
            return;
        }

        $this->actions = array();
        $action = HMWP_Classes_Tools::getValue('action');
        $nonce = HMWP_Classes_Tools::getValue('hmwp_nonce');

        if ($action == '' || $nonce == '') {
            return;
        }

        $actions = $this->getActionsTable();

        foreach ( $actions as $block ) {
            /* if there is a single action */
            if ( isset( $block['actions']['action'] ) ) {
                /* if there are more actions for the current block */
                if ( ! is_array( $block['actions']['action'] ) ) {
                    /* add the action in the actions array */
                    if ( $block['actions']['action'] == $action ) {
                        $this->actions[] = array( 'class' => $block['name'] );
                    }
                } else {
                    /* if there are more actions for the current block */
                    foreach ( $block['actions']['action'] as $value ) {
                        /* add the actions in the actions array */
                        if ( $value == $action ) {
                            $this->actions[] = array( 'class' => $block['name'] );
                        }
                    }
                }
            }
        }


        if ($ajax) {
            check_ajax_referer($action, 'hmwp_nonce');
        } else {
            check_admin_referer($action, 'hmwp_nonce');
        }
        /* add the actions in WP */
        foreach ($this->actions as $actions) {
            HMWP_Classes_ObjController::getClass($actions['class'])->action();
        }
    }

}