<?php
defined( 'ABSPATH' ) || die( 'Cheatin\' uh?' );

class HMWP_Classes_Error {

    /** @var array */
    private static $errors = array();

    public function __construct(){
        add_action('admin_notices', array($this, 'hookNotices'));
    }

    /**
     * Show the error in wrodpress
     *
     * @param string $error
     * @param string $type
     * @param null $index
     */
    public static function setError($error = '', $type = 'notice', $index = null) {
        if($type == 'notice' && $ignore_errors = (array)HMWP_Classes_Tools::getOption('ignore_errors')){
            if(!empty($ignore_errors) && in_array(md5($error),$ignore_errors)){
                return;
            }
        }

        self::$errors[md5($error)] = array(
            'type' => $type,
            'text' => $error);
    }

    /**
     * Return if error
     * @return bool
     */
    public static function isError() {
        return !empty(self::$errors);
    }

    /**
     * This hook will show the error in WP header
     */
    public function hookNotices() {
        if (is_array(self::$errors) &&
            ((is_string(HMWP_Classes_Tools::getValue('page', '')) && stripos(HMWP_Classes_Tools::getValue('page', ''), _HMWP_NAMESPACE_) !== false) ||
                (is_string(HMWP_Classes_Tools::getValue('plugin', '')) && stripos(HMWP_Classes_Tools::getValue('plugin', ''), _HMWP_PLUGIN_NAME_) !== false))
        ) {
            foreach (self::$errors as $error) {
                self::showError($error['text'], $error['type']);
            }
        }
        self::$errors = array();
    }

    /**
     * Show the notices to WP
     *
     * @param $message
     * @param string $type
     */
    public static function showError($message, $type = '') {

        //Initialize WordPress Filesystem
        $wp_filesystem = HMWP_Classes_ObjController::initFilesystem();

        if ($wp_filesystem->exists(_HMWP_THEME_DIR_ . 'Notices.php')) {
            include(_HMWP_THEME_DIR_ . 'Notices.php');
        } else {
            echo $message;
        }
    }

    /**
     * Run the actions on submit
     * @throws Exception
     */
    public function action() {

        if (!HMWP_Classes_Tools::userCan('hmwp_manage_settings')) {
            return;
        }

        switch (HMWP_Classes_Tools::getValue('action')) {
            case 'hmwp_ignoreerror':
                $hash = HMWP_Classes_Tools::getValue('hash');

                $ignore_errors = (array)HMWP_Classes_Tools::getOption('ignore_errors');

                array_push($ignore_errors, $hash);
                $ignore_errors = array_unique($ignore_errors);
                $ignore_errors = array_filter($ignore_errors);

                HMWP_Classes_Tools::saveOptions('ignore_errors',$ignore_errors);

                wp_redirect(remove_query_arg( array('hmwp_nonce', 'action', 'hash') ));

                break;
        }
    }

}
